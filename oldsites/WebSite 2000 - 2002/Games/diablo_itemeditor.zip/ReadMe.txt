Advanced Item Editor V 1.0.xxx Readme.Txt	10/01/99
------------------------------------------------------------

Contents

	Min System Requirements
	Advanced Item Editor File Formats.
	About Advanced Item Editor
	Notes on Advanced Item Editor
	Notes on ItemEdit.txt
	Known Bugs
	Other Things


Advanced Item Editor has been tested on:-
Windows 95
Windows 95b
Windows 98
Windows NT 4.0 Workstation and Server

Advanced Item Editor V 1.1.xxx will be released soon

------------------------------------------------------------

Min System Requirements:

486 DX 33
Windows 95

Visual Basic Runtimes
Tabctl32.ocx (Included Copy to xxx\windows\system Directory where xxx is the drive windows is installed)
Comdlg32.ocx (Included Copy to xxx\windows\system Directory where xxx is the drive windows is installed)
ItemEdit.Txt (Included)
ItemEdit.Dll (Included)

------------------------------------------------------------

Advanced Item Editor File Formats.

Loading:-
ITM		Loads Items OK
HIF		Loads Items OK
DIE		Loads Items OK
MIF		Loads Most Items OK but some will come out strange
		This file format is just about readable.

DID		Not Supported due to saved Items are Incorrect
		I might support it in next release if CutiX gets his file format sorted.

Saving:-
ITM		Saves OK and tested in Diablo and Hellfire
HIF		Saves OK and tested in Hellfire

------------------------------------------------------------

About Advanced Item Editor

I decided to create the editor in visual basic 5.0
Due to the fact the code is very easy to change.

I made the editor as easy to use as I could and
Tried to support as many different item types as I could find on the Net.

------------------------------------------------------------

Notes on Advanced Item Editor

When the Item Editor loads 
It will first try to find ItemEdit.txt File If this file is not found the item editor will not load
Next it will try to find ItenEdit.dll File If this file is not found then no graphics will be displayed.

ItemEdit.Dll file contains all the Item and Spell graphics.
ItemEdit.Txt File contains all the values for listboxes in the Item Editor. (See Section below)


Advanced Item Editor will check all values in text and list boxes for the correct range of numbers.
eg. if you enter a value of -1 or 256 in a text box and values from 0-255 
Are only allowed then the text box will be reset to 0
Some text boxes will support values from -16777215 to +16777215 (Max for most boxes)
Where as some will only support values from 0 to 255 or -127 to +128
All List boxes allows for values of 0 to 255 only

------------------------------------------------------------

Notes on Editing ItemEdit.Txt

This file contains all the values for the list boxes in Advanced Item Editor.
If you edit this file then Advanced Item Editor can behave strange or crash so beware.

Each List In this file begins with a name in [] followed by a list of values.
eg
[Some Name]	(List Name)
000 - Value 0	(List Values)
001 - Value 1
002 - Value 2
003 - Value 3
\/    \/
255 - Value 255
etc.

The name in [] is the list name.
and the others are the values for the list.

If you change the values in [] then Advanced Item Editor Will not load it.

Each list value must start with a number 000
And end in a max value of 255


When changing a list value then do not change the number

If you add a new list value to the end of a list then
You must include the values from the old end to the new end.
eg.

 Right Way		 Wrong Way
[Some Name]		[Some Name]
000 - Value 0		000 - Value 0
001 - Value 1		001 - Value 1
002 - Value 2		002 - Value 2
003 - Value 3		003 - Value 3
004 - Value 4		006 - Value 6
005 - Value 5
006 - Value 6

As you see if you add 006 and do not add 004 and 005 then the Item Editor will Crash.

If you delete a value then renumber all number values from 000 onwards.

[NameTypeSub] List Only

[NameTypeSub] is used for the Multiplier1/2 sub lists of Advanced Item Editor.

This has a different format to the above.

Each list begins with a number in []
The Number in [] is linked to a number in the Multiplier1/2 list
Followed by the values for that number
eg

[002]
Value 1
Value 2
etc

You can add, change or delete the values under [xxx] with out any problems.

If you add a new Number in [] then you must include values for that number or it will be blank.

------------------------------------------------------------

Known Bugs

This is the section I hate.

All Programs have got bugs some more then others.

Following is a list of bugs that I know about.

1. Advanced Item Editor is case sensitive when looking for the Files ItemEdit.dll and ItemEdit.Txt
2. The Previous Loaded list in Advanced Item Editor some times loses the file location.
3. My Spelling.

------------------------------------------------------------

Other Things.

At the moment I have not got a web address on the net
so please post all problems or suggestion's to the Diablo news group.

ALWAYES Remember to Backup your Diablo or Hellfire character.

All Graphics used in Advanced Item Editor I Downloaded from the Net.

Blizzard and Sierra do not or will never support Advanced Item Editor.

So please DO NOT send them any questions about Advanced Item Editor.

I WILL NOT BE HELD RESPONSIBLE FOR ENY LOSS OR DAMAGE TO FILES WHEN RUNNING ADVANCED ITEM EDITOR.
USE ADVANCED ITEM EDITOR AT YOUR OWN RISK.

DIABLO Copyright (c) 1996 BLIZZARD ENTERTAINMENT, All rights reserved.
HELLFIRE Copyright (c) 1997 Sierra On-Line, Inc. All rights reserved.

------------------------------------------------------------

THE END

By

The Shining One