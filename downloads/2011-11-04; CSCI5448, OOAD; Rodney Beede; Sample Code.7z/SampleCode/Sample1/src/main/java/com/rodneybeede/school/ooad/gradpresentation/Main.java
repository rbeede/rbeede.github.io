package com.rodneybeede.school.ooad.gradpresentation;

import java.util.ArrayList;
import java.util.Collection;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Restrictions;

import com.rodneybeede.school.ooad.gradpresentation.utils.LoggingUtils;
import com.rodneybeede.school.ooad.gradpresentation.utils.StringUtils;

/**
 * @author rbeede Rodney Beede
 * 
 *         CSCI5448 - Object Oriented Analysis & Design
 * 
 *         Graduate Presentation - Sample Code
 * 
 *         Due 2011-11-04
 * 
 *         Please see project pom.xml for copyright and licensing
 * 
 */
public class Main {
	private static final Logger log = Logger.getLogger(Main.class);
	
	private static SessionFactory sessionFactory;

	/**
	 * @param args
	 */
	public static void main(final String[] args) {
		System.out.println("Logging to " + StringUtils.join(LoggingUtils.getAppenderFiles(Logger.getRootLogger()), "\t"));

		sessionFactory = getDefaultSessionFactory();
		
		
		final Collection<Sample> samples = new ArrayList<Sample>();
		samples.add(new Sample("Sample 1"));
		samples.add(new Sample("Sample 2"));
		samples.add(new Sample("Sample 3"));
		
		
		/****** SAVE THE DATA ******/
		saveData(samples);
		
		
		/****** CLEAR THE LIST ******/
		samples.clear();
		
		
		/****** READ THE ALL THE DATA CURRENTLY IN THE DATABASE ******/
		samples.addAll(readData());
		
		
		// Output back the results
		for(final Sample sample : samples) {
			log.info(sample.toString());
		}
		
		
		// Always tidy up
		sessionFactory.close();
		
		log.info("Ending program");
	}

	private static SessionFactory getDefaultSessionFactory() {
		try {
			// Create the SessionFactory from hibernate.cfg.xml
			return new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) {
			// Make sure you log the exception, as it might be swallowed
			log.error("Initial SessionFactory creation failed.", ex);
			throw new ExceptionInInitializerError(ex);
		}

	}
	
	
	private static void saveData(final Collection<Sample> samples) {
		// Do for each thread
		// Don't use org.hibernate.classic.Session as it is deprecated
		org.hibernate.Session session = sessionFactory.getCurrentSession();  
		session.beginTransaction();
		
		
		// WARNING, if you are going to be inserting 1,000's of objects or objects that take lots of memory be warned
		//	that Hibernate caches bulk inserts/updates into memory
		// See http://docs.jboss.org/hibernate/core/3.6/reference/en-US/html_single/#batch
		//	for a solution.
		
		
		for(final Sample sample : samples) {
			session.save(sample);
		}
		
		
		// Send the data and ends the transaction
		session.getTransaction().commit();
	}
	
	
	
	private static Collection<Sample> readData() {
		// Do for each thread
		// Don't use org.hibernate.classic.Session as it is deprecated
		org.hibernate.Session session = sessionFactory.getCurrentSession();
		
		session.beginTransaction();
		
		final Criteria criteria = session.createCriteria(Sample.class);
		criteria.add(Restrictions.like("name", "%"));  // just gets everything like default would
		
		@SuppressWarnings("unchecked")  // annoying but that API doesn't have generics in it
		final Collection<Sample> results = criteria.list();
		
		session.getTransaction().commit();
		
		return results;
	}

}
