package com.rodneybeede.school.ooad.gradpresentation.utils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.AppenderAttachable;

public class LoggingUtils {
	/**
	 * @param logger Usually {@link Logger#getRootLogger()}
	 * @return File handle objects to all appenders that subclass {@link FileAppender} and have file settings != null.  Recursive.
	 */

	@SuppressWarnings("unchecked")
	public static Collection<File> getAppenderFiles(final org.apache.log4j.Logger logger) {
		return getAppenderFiles(logger.getAllAppenders());
	}
	

	public static Collection<File> getAppenderFiles(final Enumeration<org.apache.log4j.Appender> appenderEnumeration) {
		final Collection<File> files = new ArrayList<File>();
		
		while(appenderEnumeration.hasMoreElements()) {
			final Appender currAppender = appenderEnumeration.nextElement();
			
			if(currAppender instanceof FileAppender) {
				final FileAppender fileAppender = (FileAppender) currAppender;
				if(null != fileAppender.getFile()) {
					files.add(new File(fileAppender.getFile()).getAbsoluteFile());
				}
			}
			if(currAppender instanceof AppenderAttachable) {
				// Recursive
				
				final AppenderAttachable appenderAttachable = (AppenderAttachable) currAppender;
				@SuppressWarnings("unchecked")
				final Enumeration<Appender> childAppenders = appenderAttachable.getAllAppenders(); 
				files.addAll(getAppenderFiles(childAppenders));
			}
		}

		return files;
	}
}
