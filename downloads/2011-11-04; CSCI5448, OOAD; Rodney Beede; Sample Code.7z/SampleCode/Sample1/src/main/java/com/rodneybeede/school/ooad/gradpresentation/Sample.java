package com.rodneybeede.school.ooad.gradpresentation;

public class Sample {
	private Long id;
	
	private String name;
	
	/* package visibility */ Sample() {
		/* package, protected, or public visibility allows for more caching and performance */
	}
	
	public Sample(final String name) {
		// this.id will be auto-generated
		this.name = name;
	}
	
	public Long getId() {
		return this.id;
	}
	
	public void setId(final Long id) {
		this.id = id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(final String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.id + "\t" + this.name;
	}
}
