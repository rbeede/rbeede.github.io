package com.rodneybeede.school.ooad.gradpresentation.utils;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Iterator;

public class StringUtils {
	public static String join(final Collection<?> items, final String separator) {
		if(null == items || items.isEmpty())  return "";
		
		final Iterator<?> iter = items.iterator();
		
		final StringBuilder sb = new StringBuilder();
		
		sb.append(iter.next());
		
		while(iter.hasNext()) {
			sb.append(separator);
			sb.append(iter.next());
		}
		
		return sb.toString();
	}
	
	
	/**
	 * @param calendar
	 * @return Date in format "yyyy-MM-dd HH-mm-ss Z"
	 */
	public static String formatDate(final Calendar calendar) {
		final Format format = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss Z");
		
		return format.format(calendar.getTime());
	}
}
