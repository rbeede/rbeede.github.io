package com.rodneybeede.school.ooad.gradpresentation;

import java.util.Date;

public class Sample {
	private Long id;
	
	private String name;
	
	/****** NEW ATTRIBUTE *****/
	private Date date;
	/****** NEW ATTRIBUTE *****/
	
	
	Sample() {
		/* package, protected, or public visibility allows for more caching and performance */
	}
	
	public Sample(final String name, final Date date) {
		// this.id will be auto-generated
		this.name = name;
		this.date = date;
	}
	
	public Long getId() {
		return this.id;
	}
	
	public void setId(final Long id) {
		this.id = id;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setName(final String name) {
		this.name = name;
	}
	
	public Date getDate() {
		return this.date;
	}
	
	public void setDate(final Date date) {
		this.date = date;
	}
	
	@Override
	public String toString() {
		// Notice how we have to now handle NULL for the non-existant data
		return this.id + "\t" + this.name + "\t" + ((null != this.date) ? this.date.toString() : "");
	}
}
