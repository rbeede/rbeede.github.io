﻿// Rodney Beede
// http://www.rodneybeede.com/

var pluginMenu = Editor.addMenu("Line Inserter");

var insertStartEndAllLinesFunc = function(){
//	prompt("Text to be inserted", function(textToInsert) {
var textToInsert = "\"";
		var insertedText = textToInsert + Editor.currentView.text;

		var regexPattern = /(\r?\n)/g;
		
		insertedText = insertedText.replace(regexPattern, textToInsert + "$1" + textToInsert);
		
		insertedText += textToInsert;
		
		
		Editor.currentView.text = insertedText;
//	});
};

pluginMenu.addItem( {
	text:"Insert \" on start and end of ALL lines",
	cmd:insertStartEndAllLinesFunc
});

//pluginMenu.addSeparator();




/* function prompt(title, callback) {
	var dialog = new Dialog({
		npp: Editor,
		html: "<form><input type='text' id='prompt_str' style='width:100%' onkeydown='Config.onKeyDown(window.event);' /></form>", 
		Height: 100,
		Width: 300,
		Top: 200,
		title: title,
		js: function(){
			this.getElementById("prompt_str").focus();
		},
		onKeyDown: function(evt) {
			var target = evt.srcElement || evt.target,
				keycode = evt.keyCode || evt.which;
				
			if (keycode == 27 || keycode == 13) { 
				// escape or enter key pressed
				var value = null;
				if (keycode == 13)
					value = target.value;
					
				dialog.close();
				
				if (callback)
					callback(target.value);
			}
		}
	});
	
	dialog.show();
} */